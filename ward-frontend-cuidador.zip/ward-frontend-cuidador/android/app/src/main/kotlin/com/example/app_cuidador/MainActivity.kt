package com.example.app_cuidador

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
