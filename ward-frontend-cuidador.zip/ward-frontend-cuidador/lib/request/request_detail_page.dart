import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:location/location.dart';
import '../map_route/map_route_page.dart';
import '../request/request_model.dart';

class RequestDetailPage extends StatefulWidget {
  final Request request;
  final LocationData? currentLocation;

  const RequestDetailPage({Key? key, required this.request, this.currentLocation}) : super(key: key);

  @override
  _RequestDetailPageState createState() => _RequestDetailPageState();
}

class _RequestDetailPageState extends State<RequestDetailPage> {
  double? distance;
  String? duration;

  @override
  void initState() {
    super.initState();
    calculateDistanceAndDuration();
  }

  Future<void> calculateDistanceAndDuration() async {
    if (widget.currentLocation != null) {
      LatLng requestLocation = LatLng(widget.request.latitude, widget.request.longitude);
      LatLng userLocation = LatLng(widget.currentLocation!.latitude!, widget.currentLocation!.longitude!);
      String apiKey = 'AIzaSyDyrP2OUOSS2djL5JL1hFUfkDd3_f6nrnc';
      String url = 'https://maps.googleapis.com/maps/api/directions/json?origin=${userLocation.latitude},${userLocation.longitude}&destination=${requestLocation.latitude},${requestLocation.longitude}&key=$apiKey';
      
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        List<dynamic> routes = data['routes'];
        if (routes.isNotEmpty) {
          var route = routes[0];
          var legs = route['legs'];
          if (legs.isNotEmpty) {
            var leg = legs[0];
            setState(() {
              distance = leg['distance']['value'] / 1000.0; 
              duration = leg['duration']['text']; 
            });
          }
        }
      }
    }
  }

  double calculateDistance(LatLng start, LatLng end) {
    const Distance distance = Distance();
    return distance.as(LengthUnit.Kilometer, start, end);
  }

  IconData getServiceIcon(String service) {
    switch (service.toLowerCase()) {
      case 'cuidado ancianos':
        return Icons.accessibility_new_rounded;
      case 'cuidado enfermos':
        return Icons.local_hospital_rounded;
      case 'cuidado niños':
        return Icons.child_care_rounded;
      case 'cuidado pacientes postrados':
        return Icons.airline_seat_flat_rounded;
      case 'cuidado convalecientes':
        return Icons.medical_services_rounded;
      default:
        return Icons.error_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    LatLng requestLocation = LatLng(widget.request.latitude, widget.request.longitude);
    LatLng userLocation = widget.currentLocation != null
        ? LatLng(widget.currentLocation!.latitude!, widget.currentLocation!.longitude!)
        : const LatLng(-38.7359, -72.5903);

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Stack(
              alignment: Alignment.topLeft,
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.4,
                  child: Image.network(
                    widget.request.photoUrl,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back,
                    color: Colors.white,),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Text(
                "${widget.request.firstName} Necesita tu ayuda!",
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 16.0),
              child: Text(
                "Esta persona necesita de tus servicios, te mostramos su información relevante",
                style: TextStyle(fontSize: 12, color: Colors.grey),
                textAlign: TextAlign.start,
              ),
            ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Text(
                widget.request.fullName,
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Text(
                widget.request.description,
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.start,
              ),
            ),
            const Divider(),
            const Padding(
              padding: EdgeInsets.only(left: 16.0),
              child: Text(
                "Servicios que suele pedir",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: widget.request.servicesRequested.map((service) {
                return Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Icon(getServiceIcon(service)),
                );
              }).toList(),
            ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Text(
                "Dirección\n${widget.request.address}",
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Text(
                'A  ${duration ?? "calculando.. tiempo"} de tu ubicación',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MapRoutePage(
                      request: widget.request,
                      currentLocation: widget.currentLocation,
                    ),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
                backgroundColor: Colors.yellow,
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              ),
              child: const Text('Aceptar servicio'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              ),
              child: const Text('Rechazar'),
            ),
          ],
        ),
      ),
    );
  }
}
