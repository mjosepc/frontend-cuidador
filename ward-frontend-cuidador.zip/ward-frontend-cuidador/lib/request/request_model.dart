class Request {
  final int id;
  final dynamic firstName;
  final dynamic fullName;
  final dynamic address;
  final dynamic photoUrl;
  final dynamic latitude;
  final dynamic longitude;
  final dynamic description;
  final dynamic status;
  final List<dynamic> servicesRequested;
  final int userId;
  final int wardId;

  Request({
    required this.id,
    required this.firstName,
    required this.fullName,
    required this.address,
    required this.photoUrl,
    required this.latitude,
    required this.longitude,
    required this.description,
    required this.status,
    required this.servicesRequested,
    required this.userId,
    required this.wardId,
  });

  factory Request.fromJson(Map<dynamic, dynamic> json) {
    return Request(
      id: json['id'] ?? 0,
      firstName: json['firstName'] ?? '',
      fullName: '${json['firstName'] ?? ""} ${json['lastName'] ?? ""}',
      address: json['address'] ?? '',
      photoUrl: json['photoUrl'] ?? '',
      latitude: json['latitude'],
      longitude: json['longitude'],
      description: json['description'],
      status: json['status'],
      servicesRequested: List<dynamic>.from(json['servicesRequested'] ?? []),
      userId: json['userId'] ?? 0,
      wardId: json['wardId'] ?? 0,
    );
  }
}
