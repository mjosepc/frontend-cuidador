import 'package:flutter/material.dart';

class BottomNavigationBarComponent extends StatelessWidget {
  const BottomNavigationBarComponent({Key? key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 75,
      child: BottomNavigationBar(
          items: [
            // principal
            BottomNavigationBarItem(
              icon: Icon(Icons.home_rounded),
              label: 'Principal',
            ),

            // historial
            BottomNavigationBarItem(
              icon: Icon(Icons.description),
              label: 'Historial',
            ),

            // ajustes
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Ajustes',
            ),
          ],
          onTap: (index) {
            _handleNavigation(context, index);
          }),
    );
  }
}

void _handleNavigation(BuildContext context, int index) {
  final currentRoute = ModalRoute.of(context)?.settings.name;

  switch (index) {
    case 0:
      if (currentRoute != '/home_page') {
        Navigator.pushNamed(context, '/home_page');
      }
      break;
    case 1:
      if (currentRoute != '/history_page') {
        Navigator.pushNamed(context, '/history_page');
      }
      break;
    case 2:
      if (currentRoute != '/user_settings_page') {
        Navigator.pushNamed(context, '/user_settings_page');
      }
      break;
  }
}
