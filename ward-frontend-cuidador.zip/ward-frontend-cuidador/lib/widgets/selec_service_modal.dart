import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SelectServiceModal extends StatefulWidget {
  const SelectServiceModal({Key? key}) : super(key: key);

  @override
  _SelectServiceModalState createState() => _SelectServiceModalState();
}

class _SelectServiceModalState extends State<SelectServiceModal> {
  final storage = FlutterSecureStorage();
  late List<dynamic> availableServices = [];

  @override
  void initState() {
    super.initState();
    _fetchAvailableServices();
  }

  Future<void> _fetchAvailableServices() async {
    final token = await storage.read(key: 'auth_token');
    final dio = Dio();
    dio.options.headers['Authorization'] = 'Bearer $token';

    final url = 'http://200.13.4.213:3000/service/all';

    try {
      final response = await dio.get(url);
      if (response.statusCode == 200) {
        setState(() {
          availableServices = response.data;
        });
      } else {
        throw Exception('Failed to load available services');
      }
    } catch (e) {
      print('Error fetching available services: $e');
    }
  }

  Future<void> _addService(int serviceId) async {
    final token = await storage.read(key: 'auth_token');
    final dio = Dio();
    dio.options.headers['Authorization'] = 'Bearer $token';

    final url = 'http://200.13.4.213:3000/service/$serviceId';

    try {
      final response = await dio.patch(url);
      if (response.statusCode == 200) {
        Navigator.pop(
            context); // Cerrar el modal después de agregar el servicio
      } else {
        throw Exception('Failed to add service: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to add service: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(
            'Selecciona un servicio',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          if (availableServices != null)
            Expanded(
              child: ListView.builder(
                itemCount: availableServices.length,
                itemBuilder: (context, index) {
                  final service = availableServices[index];
                  return ListTile(
                    title: Text(service['tag']),
                    subtitle: Text(service['description']),
                    onTap: () {
                      _addService(service['id']);
                    },
                  );
                },
              ),
            ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(
                  context); // Cerrar el modal sin seleccionar ningún servicio
            },
            child: Text('Cancelar'),
          ),
        ],
      ),
    );
  }
}
