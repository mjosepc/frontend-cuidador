import 'package:app_cuidador/map_route/map_route_page.dart';
import 'package:app_cuidador/request/request_model.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class RequestDetailModal extends StatelessWidget {
  final int id;
  final String fullName;
  final String address;
  final double latitude;
  final double longitude;
  final List<dynamic> servicesRequested;
  String? authToken;
  final int wardId;
  final storage = FlutterSecureStorage();

  RequestDetailModal({
    required this.id,
    required this.fullName,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.servicesRequested,
    this.authToken,
    required this.wardId,
  });

  // Función para obtener el token del storage
  Future<void> _getToken() async {
    authToken = await storage.read(key: 'auth_token');
  }

  // Función para aceptar la solicitud
  Future<void> _acceptRequest(BuildContext context) async {
    await _getToken(); // Asegúrate de llamar correctamente _getToken()

    if (authToken == null) {
      // Manejar el caso en que authToken sea nulo
      print('Error: Token de autenticación no disponible');
      return;
    }

    try {
      Dio dio = Dio();
      var response = await dio.patch(
        'http://200.13.4.213:3000/aid/ward/accept/$id',
        options: Options(headers: {
          'Authorization': 'Bearer $authToken',
        }),
      );
      // Loguear la respuesta
      print('Respuesta aceptar solicitud: ${response.data}');

      Navigator.pop(context); // Cerrar el modal

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MapRoutePage(
            request: Request(
              id: id,
              firstName: fullName,
              fullName: fullName,
              address: address,
              latitude: latitude,
              photoUrl: "",
              description: "Sin descripcion",
              status: "Accepted",
              longitude: longitude,
              servicesRequested: servicesRequested,
              userId: id,
              wardId: wardId,
            ),
          ),
        ),
      );
      // Aquí puedes agregar lógica adicional después de aceptar la solicitud
    } catch (e) {
      // Loguear el error
      print('Error al aceptar la solicitud: $e');
    }
  }

  // Función para rechazar la solicitud
  Future<void> _rejectRequest(BuildContext context) async {
    await _getToken(); // Asegúrate de llamar correctamente _getToken()

    if (authToken == null) {
      // Manejar el caso en que authToken sea nulo
      print('Error: Token de autenticación no disponible');
      return;
    }

    try {
      Dio dio = Dio();
      var response = await dio.patch(
        'http://200.13.4.213:3000/aid/$id',
        options: Options(headers: {
          'Authorization': 'Bearer $authToken',
        }),
      );

      // Loguear la respuesta
      print('Respuesta rechazar solicitud: ${response.data}');

      Navigator.pop(context); // Cerrar el modal
    } catch (e) {
      // Loguear el error
      print('Error al rechazar la solicitud: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Detalles de la solicitud'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Nombre completo: $fullName'),
          Text('Dirección: $address'),
          Text('Latitud: $latitude, Longitud: $longitude'),
          Text(
              'Servicios solicitados: ${servicesRequested.isEmpty ? 'Servicio de minusválidos' : servicesRequested}'),
        ],
      ),
      actions: [
        ElevatedButton(
          onPressed: () => _acceptRequest(context),
          child: Text('Aceptar'),
        ),
        ElevatedButton(
          onPressed: () => _rejectRequest(context),
          child: Text('Rechazar'),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context); // Cerrar el modal sin acciones
          },
          child: Text('Cancelar'),
        ),
      ],
    );
  }
}
