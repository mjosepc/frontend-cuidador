import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class CreateServiceModal extends StatefulWidget {
  @override
  _CreateServiceModalState createState() => _CreateServiceModalState();
}

class _CreateServiceModalState extends State<CreateServiceModal> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _tagController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final storage = FlutterSecureStorage();
  bool _isLoading = false;

  Future<void> _createService() async {
    if (_formKey.currentState?.validate() ?? false) {
      final token = await storage.read(key: 'auth_token');
      setState(() {
        _isLoading = true;
      });

      final tag = _tagController.text;
      final description = _descriptionController.text;
      final dio = Dio();

      dio.options.headers['Authorization'] = 'Bearer $token';
      final url = 'http://200.13.4.213:3000/service/new';

      try {
        final response = await dio.post(
          url,
          data: {'tag': tag, 'description': description},
        );

        if (response.statusCode == 200) {
          Navigator.pop(context);
          // Puedes actualizar la lista de servicios aquí si es necesario
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(
                    'Failed to create service: ${response.statusMessage}')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create service: $e')),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Crear Servicio'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: _tagController,
              decoration: InputDecoration(labelText: 'Tag'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese un tag';
                }
                return null;
              },
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Descripción'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese una descripción';
                }
                return null;
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: _isLoading ? null : _createService,
          child: _isLoading ? CircularProgressIndicator() : Text('Crear'),
        ),
      ],
    );
  }
}
