import 'package:flutter/material.dart';
import 'package:easy_stepper/easy_stepper.dart';

class StepperWidget extends StatelessWidget {
  final int activeStep;
  final List<String> titles;
  
  const StepperWidget({super.key, required this.activeStep, required this.titles});

  @override
  Widget build(BuildContext context) {
    return EasyStepper(
      activeStep: activeStep,
      activeStepTextColor: Colors.black87,
      finishedStepTextColor: Colors.black87,
       lineStyle: const LineStyle(
                    lineLength:20,
                    lineType: LineType.normal,
                    lineThickness: 4,
                    lineSpace: 0,
                    unreachedLineType: LineType.normal,
                    unreachedLineColor: Colors.grey,
                    defaultLineColor: Colors.grey,
                    activeLineColor: Colors.black,
                    finishedLineColor: Colors.black
                  ),
      finishedStepBackgroundColor: Colors.black,
      unreachedStepBackgroundColor: Colors.grey,
      activeStepBackgroundColor: Colors.black,
      internalPadding: 40,
      showLoadingAnimation: true,
      borderThickness: 4,
      stepRadius:15,
      steps: titles.map((title) {
        int index = titles.indexOf(title);
        return EasyStep(
          customStep: CircleAvatar(
            radius: 4,
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: 4,
              backgroundColor: activeStep >= index ? Colors.black : Colors.white,
            ),
          ),
          title: title,
          topTitle: true
        );
      }).toList(),
      onStepReached: (index) {
        
      },
    );
  }
}