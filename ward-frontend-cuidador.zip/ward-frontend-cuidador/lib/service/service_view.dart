import 'dart:async';
import 'package:flutter/material.dart';
import '../widgets/stepper/stepper_widget.dart';
import '../request/request_model.dart';
import '../widgets/modal/confirmation_dialog.dart';

class ServiceView extends StatefulWidget {
  final Request request;
  final double defaultPricePerHour;

  const ServiceView({
    Key? key,
    required this.request,
    this.defaultPricePerHour = 12000,
  }) : super(key: key);

  @override
  _ServiceViewState createState() => _ServiceViewState();
}

class _ServiceViewState extends State<ServiceView> {
  late Timer _timer;
  int _elapsedMinutes = 0;
  int _currentStep = 1;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(minutes: 1), (timer) {
      setState(() {
        _elapsedMinutes++;
      });
    });
  }

  void _showConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return ConfirmationDialog(
          title: '¿Desea terminar el servicio?',
          content:
              'Al terminar el servicio, se solicitará el pago al solicitante.',
          onConfirm: () {
            Navigator.of(context).pop(true);
          },
          onCancel: () {
            Navigator.of(context).pop(false);
          },
        );
      },
    ).then((confirmed) {
      if (confirmed != null && confirmed) {
        _showLoadingModal();
        _updateStep();
      }
    });
  }

  void _updateStep() {
    setState(() {
      _currentStep = 2;
    });
  }

  void _showLoadingModal() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const AlertDialog(
          title: Text('Esperando pago'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Por favor, espere...'),
            ],
          ),
        );
      },
    );

    Future.delayed(const Duration(seconds: 2), () {
      Navigator.of(context).popUntil(ModalRoute.withName('/'));
    });
  }

  @override
  Widget build(BuildContext context) {
    final int hours = _elapsedMinutes ~/ 60;
    final int minutes = _elapsedMinutes % 60;
    final double totalCost =
        (hours + minutes / 60) * widget.defaultPricePerHour;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                height: MediaQuery.of(context).size.height / 3,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/cuidador.png'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Cuida bien de ${widget.request.firstName}',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Que tengas una buena jornada, cumple con tu servicio con amabilidad y respeto.',
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                child: StepperWidget(
                  activeStep: _currentStep,
                  titles: const [
                    'En camino',
                    'Inicio del servicio',
                    'Fin del servicio'
                  ],
                ),
              ),
              Center(
                child: Image.asset(
                  'assets/salud.png',
                  width: 100,
                  height: 100,
                ),
              ),
              Column(
                children: [
                  Text(
                    'Han transcurrido\n$hours horas y $minutes minutos',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Total de servicio: \$$totalCost',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 14),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: _showConfirmationDialog,
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 5),
                  ),
                  child: Text('Terminar servicio · \$$totalCost'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
