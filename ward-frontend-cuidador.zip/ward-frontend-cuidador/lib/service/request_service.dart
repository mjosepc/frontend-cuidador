import 'dart:async';
import 'dart:convert';
import 'package:dart_amqp/dart_amqp.dart';
import '../request/request_model.dart';

class RequestService {
  final String queueName = "aid_requests_queue";
  Client? _client;
  final _requestController = StreamController<List<Request>>.broadcast();
  List<Request> _requests = [];

  Stream<List<Request>> get requestStream => _requestController.stream;

  Future<void> initialize() async {
    ConnectionSettings settings = ConnectionSettings(
      host: "200.13.4.213",
      port: 5672,
      authProvider: const PlainAuthenticator('sauce', 'Ward-kHpo&0E2d3R&'),
    );

    _client = Client(settings: settings);

    try {
      Channel channel = await _client!.channel();
      print("Conectado a RabbitMQ channel: $channel");
      Queue queue = await channel.queue(queueName, durable: true);
      print("Conectado a RabbitMQ queue: $queue");
      Consumer consumer = await queue.consume(consumerTag: "flutter_consumer");
      consumer.listen((AmqpMessage message) {
        String payload = message.payloadAsString;
        print("Mensaje recibido de RabbitMQ:");
        print(payload);

        Map<String, dynamic> data = jsonDecode(payload);

        if (data.containsKey('pattern') &&
            data['pattern'] == 'aid-request-placed') {
          if (data.containsKey('data')) {
            var requestData = data['data'];
            if (requestData is Map<String, dynamic>) {
              Request request = Request.fromJson(requestData);
              _addRequest(request);
            }
          }
        } else {
          print("Patrón no coincide, mensaje ignorado.");
        }
      });
    } catch (e) {
      print("Error al conectarse a RabbitMQ: $e");
    }
  }

  void _addRequest(Request request) {
    print("Añadiendo solicitud: $request");
    _requests.add(request);
    _requestController.add(_requests);
  }

  void close() {
    _client?.close();
    _requestController.close();
  }
}
