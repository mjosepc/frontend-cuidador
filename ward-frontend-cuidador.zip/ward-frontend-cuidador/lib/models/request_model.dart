class Request {
  final int id;
  final String firstName;
  final String fullName;
  final String address;
  final String photoUrl;
  final double? latitude; // Permitir null en latitude
  final double? longitude; // Permitir null en longitude
  final String? description; // Permitir null en description
  final List<String> servicesRequested;
  final int userId;
  final String status;

  Request({
    required this.id,
    required this.firstName,
    required this.fullName,
    required this.address,
    required this.photoUrl,
    required this.servicesRequested,
    this.latitude,
    this.longitude,
    this.description,
    required this.userId,
    required this.status,
  });

  factory Request.fromJson(Map<dynamic, dynamic> json) {
    return Request(
      id: json['id'] ?? 0, // Ajusta el valor por defecto según tu necesidad
      userId:
          json['userId'] ?? 0, // Ajusta el valor por defecto según tu necesidad
      firstName: json['firstName'] ?? '', // Asigna una cadena vacía si es null
      fullName: '${json['firstName'] ?? ""} ${json['lastName'] ?? ""}',
      address: json['address'] ?? '',
      photoUrl: json['photoUrl'] ?? '',
      latitude: json['latitude'] != null ? json['latitude'].toDouble() : null,
      longitude:
          json['longitude'] != null ? json['longitude'].toDouble() : null,
      description: json['description'], // Permitir que sea null
      status: json['status'] ?? '', // Asigna una cadena vacía si es null
      servicesRequested: List<String>.from(json['servicesRequested'] ?? []),
    );
  }
}
