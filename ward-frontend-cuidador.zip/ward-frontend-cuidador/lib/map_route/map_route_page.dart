import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:location/location.dart';
import 'package:http/http.dart' as http;
import '../request/request_model.dart';
import '../widgets/stepper/stepper_widget.dart';
import '../service/service_view.dart';

class MapRoutePage extends StatefulWidget {
  final Request request;
  final LocationData? currentLocation;

  const MapRoutePage({Key? key, required this.request, this.currentLocation})
      : super(key: key);

  @override
  _MapRoutePageState createState() => _MapRoutePageState();
}

class _MapRoutePageState extends State<MapRoutePage> {
  String? duration;
  String? address;

  @override
  void initState() {
    super.initState();
    getRoute();
    getAddress();
  }

  Future<void> getRoute() async {
    LatLng requestLocation =
        LatLng(widget.request.latitude, widget.request.longitude);
    LatLng userLocation = widget.currentLocation != null
        ? LatLng(widget.currentLocation!.latitude!,
            widget.currentLocation!.longitude!)
        : LatLng(widget.request.latitude, widget.request.longitude);

    String apiKey = 'AIzaSyDyrP2OUOSS2djL5JL1hFUfkDd3_f6nrnc';
    String url =
        'https://maps.googleapis.com/maps/api/directions/json?origin=${userLocation.latitude},${userLocation.longitude}&destination=${requestLocation.latitude},${requestLocation.longitude}&mode=driving&key=$apiKey';

    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final legs = data['routes'][0]['legs'];
      if (legs.isNotEmpty) {
        final leg = legs[0];
        setState(() {
          duration = leg['duration']['text'];
        });
      }
    } else {
      throw Exception('Failed to load route');
    }
  }

  Future<void> getAddress() async {
    LatLng requestLocation =
        LatLng(widget.request.latitude, widget.request.longitude);

    String apiKey = 'AIzaSyDyrP2OUOSS2djL5JL1hFUfkDd3_f6nrnc';
    String url =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${requestLocation.latitude},${requestLocation.longitude}&key=$apiKey';

    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['results'].isNotEmpty) {
        setState(() {
          address = data['results'][0]['formatted_address'];
        });
      }
    } else {
      throw Exception('Failed to load address');
    }
  }

  @override
  Widget build(BuildContext context) {
    LatLng requestLocation =
        LatLng(widget.request.latitude, widget.request.longitude);
    LatLng userLocation = widget.currentLocation != null
        ? LatLng(widget.currentLocation!.latitude!,
            widget.currentLocation!.longitude!)
        : LatLng(widget.request.latitude, widget.request.longitude);

    // Define la distancia de tolerancia
    const double toleranceDistance = 16.0;

    double distance = calculateDistance(userLocation, requestLocation);

    // Comprueba si la distancia está dentro de la tolerancia
    bool isWithinTolerance = distance <= toleranceDistance;

    if (isWithinTolerance) {
      print("Ok!");
      Future.microtask(() => Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ServiceView(request: widget.request),
            ),
          ));
    }

    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            const Text(
              'El deber llama!',
              textAlign: TextAlign.start,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text(
              'Aceptaste la solicitud de ${widget.request.firstName}, no te retrases',
              textAlign: TextAlign.start,
            ),
            const SizedBox(height: 8),
            Text(
              'Llegas en ${duration ?? "calculando tiempo..."}',
              textAlign: TextAlign.start,
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text(
              'Dirección de destino: ${address ?? "obteniendo dirección..."}',
              textAlign: TextAlign.start,
              style: const TextStyle(fontSize: 16, color: Colors.black),
            ),
            const SizedBox(height: 16),
            const StepperWidget(
              activeStep: 0,
              titles: ['En camino', 'Inicio del servicio', 'Fin del servicio'],
            ),
            ElevatedButton(
              onPressed: () {
                // Llamar a la acción
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellow,
                foregroundColor: Colors.black,
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 32),
              ),
              child: Text('Llamar a ${widget.request.firstName}'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                // Cancelar servicio
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 32),
              ),
              child: const Text('Cancelar servicio'),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  double calculateDistance(LatLng start, LatLng end) {
    const Distance distance = Distance();
    return distance.as(LengthUnit.Meter, start, end);
  }
}
