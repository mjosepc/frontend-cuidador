import 'package:app_cuidador/regist/regist_page.dart';
import 'package:flutter/material.dart';
import 'package:app_cuidador/login/login_page.dart';
import 'package:app_cuidador/home/home_page.dart';
import 'package:app_cuidador/user_config/user_config.dart';
import 'package:app_cuidador/history/history.dart';
import 'package:app_cuidador/map_route/map_route_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const LoginPage(),
      routes: {
        '/home_page': (context) => const HomePage(),
        '/regist_page': (context) => const RegistPage(),
        '/login_page': (context) => const LoginPage(),
        '/user_settings_page': (context) => const ConfigurationPage(),
        '/history_page': (context) => const HistorialServiciosPage(),
      },
    );
  }
}
