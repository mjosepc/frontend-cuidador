import 'package:flutter/material.dart';

class MisServiciosPage extends StatelessWidget {
  final List<dynamic>? servicios;

  const MisServiciosPage({Key? key, this.servicios}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Mis servicios',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
          const SizedBox(height: 10),
          servicios != null && servicios!.isNotEmpty
              ? Expanded(
                  child: ListView.builder(
                    itemCount: servicios!.length,
                    itemBuilder: (context, index) {
                      final servicio = servicios![index];
                      return ListTile(
                        title: Text(servicio['name']),
                        subtitle: Text(servicio['description']),
                      );
                    },
                  ),
                )
              : const Center(
                  child: Text(
                    'No hay servicios disponibles',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
        ],
      ),
    );
  }
}
