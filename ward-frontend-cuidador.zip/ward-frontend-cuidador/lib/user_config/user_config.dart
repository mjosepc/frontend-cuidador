import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import './pages/information_page.dart';
import './pages/services.dart'; // Importa la clase Request
import 'package:app_cuidador/widgets/bottom_navbar/bottom_navbar.dart';
import 'package:app_cuidador/widgets/selec_service_modal.dart';
import 'package:app_cuidador/widgets/create_service_modal.dart'; // Importa CreateServiceModal

class ConfigurationPage extends StatefulWidget {
  const ConfigurationPage({Key? key}) : super(key: key);

  @override
  _ConfigurationPageState createState() => _ConfigurationPageState();
}

class _ConfigurationPageState extends State<ConfigurationPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late Future<Map<String, dynamic>> _cuidadorData;
  final storage = FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _cuidadorData = _fetchCuidadorData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configuración'),
        backgroundColor: Colors.grey[300],
        bottom: TabBar(
          controller: _tabController,
          tabs: const <Widget>[
            Tab(
              text: 'Información básica',
            ),
            Tab(
              text: 'Mis servicios',
            )
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          FutureBuilder(
            future: _cuidadorData,
            builder: (context, AsyncSnapshot<Map<String, dynamic>> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else if (!snapshot.hasData) {
                return const Center(child: Text('No hay datos disponibles'));
              } else {
                final data = snapshot.data!;
                return InformationPage(
                  nombre: '${data['firstName']} ${data['lastName']}',
                  telefono: data['phoneNumber'] ?? 'No disponible',
                  email: data['email'],
                  photoUrl:
                      'assets/cuidador.png', // Ajusta según la estructura de tu data
                );
              }
            },
          ),
          // Deja esta pestaña para configuraciones posteriores
          FutureBuilder(
            future: _cuidadorData,
            builder: (context, AsyncSnapshot<Map<String, dynamic>> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else if (!snapshot.hasData) {
                return const Center(child: Text('No hay datos disponibles'));
              } else {
                final services = snapshot.data!['services'] as List<dynamic>;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              showModalBottomSheet(
                                context: context,
                                builder: (context) => SelectServiceModal(),
                              );
                            },
                            child: Text('Agregar Servicios'),
                          ),
                          SizedBox(width: 8), // Espacio entre los botones
                          ElevatedButton(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) => CreateServiceModal(),
                              );
                            },
                            child: Text('Crear Servicio'),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: services.length,
                        itemBuilder: (context, index) {
                          final service = services[index];
                          return ListTile(
                            title: Text(service['tag']),
                            subtitle: Text(service['description'] ?? ''),
                            // Puedes añadir más acciones o detalles aquí si lo deseas
                          );
                        },
                      ),
                    ),
                  ],
                );
              }
            },
          ),
        ],
      ),
      bottomNavigationBar: const BottomNavigationBarComponent(),
    );
  }

  Future<Map<String, dynamic>> _fetchCuidadorData() async {
    final token =
        await storage.read(key: 'auth_token'); // Lee el token almacenado
    final dio = Dio();
    dio.options.headers['Authorization'] = 'Bearer $token';

    final url = 'http://200.13.4.213:3000/auth/me';

    try {
      final response = await dio.get(url);
      if (response.statusCode == 200) {
        Map<String, dynamic> userData = response.data;
        return userData;
      } else {
        throw Exception('Failed to load cuidador data');
      }
    } catch (e) {
      throw Exception('Failed to load cuidador data: $e');
    }
  }
}
