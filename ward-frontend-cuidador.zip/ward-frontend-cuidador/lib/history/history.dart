import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:app_cuidador/models/request_model.dart';
import 'package:app_cuidador/widgets/bottom_navbar/bottom_navbar.dart';

class HistorialServiciosPage extends StatefulWidget {
  const HistorialServiciosPage({Key? key}) : super(key: key);

  @override
  _HistorialServiciosPageState createState() => _HistorialServiciosPageState();
}

class _HistorialServiciosPageState extends State<HistorialServiciosPage> {
  late Future<List<Request>> _requestsFuture;

  @override
  void initState() {
    super.initState();
    _requestsFuture = fetchRequests();
  }

  Future<List<Request>> fetchRequests() async {
    var dio = Dio();
    var url =
        'https://mocki.io/v1/47dad1f5-1776-466b-9c20-9147f1e12ef0'; // Cambia esto por tu endpoint real

    try {
      var response = await dio.get(url);
      if (response.statusCode == 200) {
        List<Request> requests = (response.data as List)
            .map((json) => Request.fromJson(json))
            .toList();
        return requests;
      } else {
        throw Exception('Failed to load requests');
      }
    } catch (e) {
      throw Exception('Failed to load requests: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Historial de servicios',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.grey[300],
      ),
      body: FutureBuilder<List<Request>>(
        future: _requestsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hay solicitudes'));
          } else {
            final requests = snapshot.data!;
            return Column(
              children: [
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    itemCount: requests.length,
                    itemBuilder: (context, index) {
                      final request = requests[index];
                      return Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 4.0, horizontal: 8.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              border: const Border(
                                right: BorderSide(
                                    color: Colors.black, width: 12.0),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: MediaQuery.of(context).size.width / 3,
                                  height: 120,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    image: DecorationImage(
                                      image: AssetImage('assets/cuidador.png'),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          request.fullName,
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          request.address,
                                          style:
                                              const TextStyle(fontSize: 12.0),
                                        ),
                                        Row(
                                          children: request.servicesRequested
                                              .map((service) => Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 8.0),
                                                    child: Icon(getServiceIcon(
                                                        service)),
                                                  ))
                                              .toList(),
                                        ),
                                        const Text(
                                          '1 hora 20 minutos - \$18000',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          }
        },
      ),
      bottomNavigationBar: const BottomNavigationBarComponent(),
    );
  }

  IconData getServiceIcon(String service) {
    switch (service.toLowerCase()) {
      case 'cuidado ancianos':
        return Icons.accessibility_new_rounded;
      case 'cuidado enfermos':
        return Icons.local_hospital_rounded;
      case 'cuidado niños':
        return Icons.child_care_rounded;
      case 'cuidado pacientes postrados':
        return Icons.airline_seat_flat_rounded;
      case 'cuidado convalecientes':
        return Icons.medical_services_rounded;
      default:
        return Icons.error_outline;
    }
  }
}
