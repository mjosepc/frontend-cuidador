import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:location/location.dart';
import 'package:app_cuidador/widgets/bottom_navbar/bottom_navbar.dart';
import 'package:app_cuidador/user_config/user_config.dart';
import 'package:app_cuidador/history/history.dart';
import 'package:app_cuidador/widgets/request_detail_modal.dart';
import 'package:dio/dio.dart';
import '../request/request_model.dart';
import '../service/request_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  LocationData? _currentLocation;
  List<Request> _requests = [];
  final RequestService _requestService = RequestService();
  int _currentIndex = 0;
  final storage = FlutterSecureStorage();
  int? _loggedInWardId;

  @override
  void initState() {
    super.initState();
    _initializeRabbitMQ();
    _subscribeToRequests();
    _getLoggedInUserWardId();
  }

  Future<void> _getLoggedInUserWardId() async {
    final token = await storage.read(key: 'auth_token');

    if (token == null) {
      print('Token is null');
      return;
    }

    try {
      final dio = Dio();
      final response = await dio.get(
        'http://200.13.4.213:3000/auth/me',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );

      if (response.statusCode == 200) {
        setState(() {
          _loggedInWardId = response.data['id'];
          print('Logged in ward id: $_loggedInWardId');
        });
      } else {
        print('Failed to load user data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  void _subscribeToRequests() {
    _requestService.requestStream.listen((requests) {
      print("Recibido stream de solicitudes: $requests");
      setState(() {
        if (_loggedInWardId != null) {
          _requests = requests
              .where((request) => request.wardId == _loggedInWardId)
              .toList();
        } else {
          _requests = [];
        }
      });
    });
  }

  @override
  void dispose() {
    _requestService.close();
    super.dispose();
  }

  void _onNavBarTap(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  Future<void> _initializeRabbitMQ() async {
    await _requestService.initialize();
  }

  Widget _buildRequestsList() {
    return ListView.builder(
      itemCount: _requests.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return RequestDetailModal(
                  id: _requests[index].userId,
                  fullName: _requests[index].fullName ?? 'Sin nombre',
                  address: _requests[index].address ?? 'Dirección desconocida',
                  latitude: _requests[index].latitude ?? 0.0,
                  longitude: _requests[index].longitude ?? 0.0,
                  servicesRequested: _requests[index].servicesRequested ?? [],
                  authToken: null, // El modal obtendrá el token
                  wardId: _loggedInWardId ??
                      0, // Proporciona un valor predeterminado si es nulo
                );
              },
            );
          },
          child: Card(
            elevation: 3,
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: ListTile(
              title: Text(
                _requests[index].fullName ?? 'Sin nombre',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(_requests[index].description ?? 'Sin descripción'),
            ),
          ),
        );
      },
    );
  }

  Widget _buildPage(int index) {
    switch (index) {
      case 0:
        // Página de Inicio
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Ubicación actual:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Latitud: ${_currentLocation?.latitude ?? "-38.7359"}',
                style: TextStyle(fontSize: 16),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Longitud: ${_currentLocation?.longitude ?? "-72.5903"}',
                style: TextStyle(fontSize: 16),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _requests.isNotEmpty
                  ? _buildRequestsList()
                  : Center(
                      child: Text('No hay solicitudes pendientes'),
                    ),
            ),
          ],
        );
      case 1:
        // Página de Configuración
        return const ConfigurationPage(); // Reemplaza con tu página de Configuración
      case 2:
        // Página de Historial
        return const HistorialServiciosPage();
      default:
        return Container();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Ward App',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.yellow,
      ),
      body: _buildPage(_currentIndex),
      bottomNavigationBar: const BottomNavigationBarComponent(),
    );
  }
}
